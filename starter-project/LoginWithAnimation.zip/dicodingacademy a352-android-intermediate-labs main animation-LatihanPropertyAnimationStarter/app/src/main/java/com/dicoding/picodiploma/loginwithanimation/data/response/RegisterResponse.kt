package com.dicoding.picodiploma.loginwithanimation.data.response

data class RegisterResponse(
	val error: Boolean? = null,
	val message: String? = null
)

